
/**
 * All external API and scraper logic has been removed as requested.
 * Recruitment is now handled via direct form submission.
 */
export {};
